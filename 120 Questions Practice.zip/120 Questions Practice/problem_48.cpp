#include <bits/stdc++.h>
using namespace std;
int main(){int q;cin>>q;vector<long long>st;
while(q--){string c;cin>>c;if(c=="push"){long long x;cin>>x;st.push_back(x);}
else if(c=="pop"){if(!st.empty())st.pop_back();}
else if(c=="top"){cout<<(st.empty()? -1: st.back())<<"\n";}}}