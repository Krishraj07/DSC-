// Elements more than n/k times
#include <bits/stdc++.h>
using namespace std;
int main(){int n,k;cin>>n>>k; vector<long long>a(n);
for(auto &x:a)cin>>x;
unordered_map<long long,int>cand;
for(long long x:a){
 if(cand.count(x)) cand[x]++;
 else if((int)cand.size()<k-1) cand[x]=1;
 else{
  vector<long long>rem;
  for(auto &p:cand) if(--p.second==0) rem.push_back(p.first);
  for(long long r:rem) cand.erase(r);
 }
}
vector<long long>ans;
for(auto &p:cand){
 int cnt=0; for(long long x:a) if(x==p.first) cnt++;
 if(cnt>n/k) ans.push_back(p.first);
}
for(auto &x:ans) cout<<x<<" "; if(ans.empty()) cout<<"None";}