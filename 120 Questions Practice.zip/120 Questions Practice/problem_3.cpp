// Kth max/min
#include <bits/stdc++.h>
using namespace std;int main(){int n,k;cin>>n>>k;vector<long long>a(n);for(auto &x:a)cin>>x;sort(a.begin(),a.end());cout<<a[k-1]<<" "<<a[n-k];}