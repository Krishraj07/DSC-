// Kadane largest sum
#include <bits/stdc++.h>
using namespace std;int main(){int n;cin>>n;long long cur=0,best=LLONG_MIN,x;while(n--){cin>>x;cur=max(x,cur+x);best=max(best,cur);}cout<<best;}