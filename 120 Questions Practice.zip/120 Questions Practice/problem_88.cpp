#include <bits/stdc++.h>
using namespace std;
// Print all permutations
void perm(string &s,int l){
    if(l==s.size()){ cout<<s<<"\n"; return; }
    for(int i=l;i<s.size();i++){
        swap(s[l],s[i]);
        perm(s,l+1);
        swap(s[l],s[i]);
    }
}
int main(){ string s; if(!(cin>>s)) return 0; perm(s,0); return 0; }
