#include <bits/stdc++.h>
using namespace std;
// Multi-source BFS example (closest distance from multiple sources)
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n,m; if(!(cin>>n>>m)) return 0;
    vector<vector<int>> grid(n, vector<int>(m));
    for(int i=0;i<n;i++) for(int j=0;j<m;j++) cin>>grid[i][j];
    vector<vector<int>> dist(n, vector<int>(m, -1));
    queue<pair<int,int>> q;
    for(int i=0;i<n;i++) for(int j=0;j<m;j++) if(grid[i][j]==1){ dist[i][j]=0; q.push({i,j}); }
    int dx[4]={-1,1,0,0}, dy[4]={0,0,-1,1};
    while(!q.empty()){
        auto [x,y]=q.front(); q.pop();
        for(int d=0;d<4;d++){
            int nx=x+dx[d], ny=y+dy[d];
            if(nx>=0 && nx<n && ny>=0 && ny<m && dist[nx][ny]==-1){
                dist[nx][ny]=dist[x][y]+1; q.push({nx,ny});
            }
        }
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++) cout<<dist[i][j]<<" ";
        cout<<"
";
    }
    return 0;
}
