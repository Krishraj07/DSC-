#include <bits/stdc++.h>
using namespace std;
// 116 - Minimum steps by Knight (on N x N)
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int N; if(!(cin>>N)) return 0;
    int sx,sy,dx,dy; cin>>sx>>sy>>dx>>dy;
    vector<vector<int>> dist(N, vector<int>(N,-1));
    int mx[8]={2,2,-2,-2,1,1,-1,-1}, my[8]={1,-1,1,-1,2,-2,2,-2};
    queue<pair<int,int>> q; q.push({sx,sy}); dist[sx][sy]=0;
    while(!q.empty()){
        auto [x,y]=q.front(); q.pop();
        if(x==dx && y==dy){ cout<<dist[x][y]<<"\n"; return 0; }
        for(int k=0;k<8;k++){
            int nx=x+mx[k], ny=y+my[k];
            if(nx>=0&&nx<N&&ny>=0&&ny<N && dist[nx][ny]==-1){
                dist[nx][ny]=dist[x][y]+1; q.push({nx,ny});
            }
        }
    }
    cout<<-1<<"\n";
    return 0;
}
