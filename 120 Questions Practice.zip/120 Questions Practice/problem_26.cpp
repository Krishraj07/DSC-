// All Pairs with Given Sum
#include <bits/stdc++.h>
using namespace std;
int main(){int n; long long T;cin>>n>>T; vector<long long>a(n);
for(auto &x:a)cin>>x; sort(a.begin(),a.end()); int l=0,r=n-1; bool ok=false;
while(l<r){ long long s=a[l]+a[r];
 if(s==T){cout<<a[l]<<" "<<a[r]<<"\n"; l++; r--; ok=true;}
 else if(s<T) l++; else r--; }
if(!ok) cout<<"No Pairs";}