// 3-way partition around x
#include <bits/stdc++.h>
using namespace std;
int main(){int n; long long x;cin>>n>>x; vector<long long>a(n);
for(auto&y:a)cin>>y;
int l=0,m=0,h=n-1;
while(m<=h){
 if(a[m]<x) swap(a[l++],a[m++]);
 else if(a[m]>x) swap(a[m],a[h--]);
 else m++;
}
for(auto &y:a)cout<<y<<" ";}