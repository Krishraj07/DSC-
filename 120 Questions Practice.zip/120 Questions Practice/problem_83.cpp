#include <bits/stdc++.h>
using namespace std;
// Check if string is rotated by two places
int main(){
    string s1,s2; if(!(cin>>s1>>s2)) return 0;
    if(s1.size()!=s2.size()){ cout<<"No\n"; return 0; }
    string left = s1.substr(2) + s1.substr(0,2);
    string right = s1.substr(s1.size()-2) + s1.substr(0,s1.size()-2);
    cout<<(s2==left || s2==right ? "Yes\n" : "No\n");
    return 0;
}
