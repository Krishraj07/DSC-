#include <bits/stdc++.h>
using namespace std;
// 110 - Create Graph and print adjacency list (0-based)
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n,m; if(!(cin>>n>>m)) return 0;
    vector<vector<int>> g(n);
    for(int i=0;i<m;i++){ int u,v; cin>>u>>v; g[u].push_back(v); g[v].push_back(u); }
    for(int i=0;i<n;i++){
        cout<<i<<": ";
        for(size_t j=0;j<g[i].size();j++) cout<<g[i][j]<<(j+1==g[i].size()?"":" ");
        cout<<"\n";
    }
    return 0;
}
