// Best time to buy/sell stock
#include <bits/stdc++.h>
using namespace std;
int main(){int n;cin>>n; long long mn=LLONG_MAX,ans=0,x;
while(n--){cin>>x; mn=min(mn,x); ans=max(ans,x-mn);} cout<<ans;}