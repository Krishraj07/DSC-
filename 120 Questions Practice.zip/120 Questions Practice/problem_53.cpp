#include <bits/stdc++.h>
using namespace std;
bool match(char a,char b){return(a=='('&&b==')')||(a=='['&&b==']')||(a=='{'&&b=='}');}
int main(){string s;cin>>s;stack<char>st;
for(char c:s){if(c=='('||c=='['||c=='{')st.push(c);else{if(st.empty()||!match(st.top(),c)){cout<<"Not Balanced";return 0;}st.pop();}}
cout<<(st.empty()? "Balanced":"Not Balanced");}