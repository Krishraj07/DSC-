#include <bits/stdc++.h>
using namespace std;
// Stack Permutations (check if output can be generated)
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n; if(!(cin>>n)) return 0;
    vector<int> input(n), output(n);
    for(int i=0;i<n;i++) cin>>input[i];
    for(int i=0;i<n;i++) cin>>output[i];
    stack<int> st;
    int j=0;
    for(int i=0;i<n;i++){
        st.push(input[i]);
        while(!st.empty() && j<n && st.top()==output[j]){
            st.pop(); j++;
        }
    }
    cout<<(j==n?"Yes\n":"No\n");
    return 0;
}
