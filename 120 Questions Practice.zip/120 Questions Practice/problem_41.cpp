#include <bits/stdc++.h>
using namespace std;
struct Node{int v;Node*next;Node(int x):v(x),next(NULL){}};
int main(){int n;cin>>n;Node*h=NULL,*t=NULL;for(int i=0;i<n;i++){int x;cin>>x;Node*p=new Node(x);if(!h)h=t=p;else t->next=p;}
Node*prev=NULL,*cur=h,*nxt=NULL;while(cur){nxt=cur->next;cur->next=prev;prev=cur;cur=nxt;}
for(Node*p=prev;p;p=p->next)cout<<p->v<<" ";}