// Max profit at most 2 transactions
#include <bits/stdc++.h>
using namespace std;
int main(){int n;cin>>n; vector<int>p(n);for(int&i:p)cin>>i;
vector<int>profit(n,0);
int maxp=p[n-1];
for(int i=n-2;i>=0;i--){ maxp=max(maxp,p[i]); profit[i]=max(profit[i+1],maxp-p[i]); }
int minp=p[0],ans=profit[0];
for(int i=1;i<n;i++){ minp=min(minp,p[i]); ans=max(ans,profit[i]+p[i]-minp); }
cout<<ans;}