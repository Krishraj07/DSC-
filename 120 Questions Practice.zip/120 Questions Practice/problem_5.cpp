// Move negatives
#include <bits/stdc++.h>
using namespace std;int main(){int n;cin>>n;vector<long long>a(n);for(auto &x:a)cin>>x;stable_partition(a.begin(),a.end(),[](long long x){return x<0;});for(long long x:a)cout<<x<<" ";}