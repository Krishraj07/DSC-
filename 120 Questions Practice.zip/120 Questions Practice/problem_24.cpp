// Count Inversions (simple merge sort)
#include <bits/stdc++.h>
using namespace std;
long long mergeC(vector<long long>&a,int l,int m,int r){
    vector<long long> L(a.begin()+l,a.begin()+m+1),R(a.begin()+m+1,a.begin()+r+1);
    int i=0,j=0,k=l; long long inv=0;
    while(i<L.size() && j<R.size()){
        if(L[i]<=R[j]) a[k++]=L[i++];
        else{ a[k++]=R[j++]; inv+=L.size()-i; }
    }
    while(i<L.size()) a[k++]=L[i++];
    while(j<R.size()) a[k++]=R[j++];
    return inv;
}
long long sortC(vector<long long>&a,int l,int r){
    if(l>=r) return 0;
    int m=(l+r)/2;
    return sortC(a,l,m)+sortC(a,m+1,r)+mergeC(a,l,m,r);
}
int main(){int n;cin>>n; vector<long long>a(n);
for(auto &x:a)cin>>x; cout<<sortC(a,0,n-1);}