#include <bits/stdc++.h>
using namespace std;
// First non-repeating character in a stream
int main(){
    string s; if(!(cin>>s)) return 0;
    vector<int> freq(26,0);
    queue<char> q;
    for(char c: s){
        freq[c-'a']++;
        q.push(c);
        while(!q.empty() && freq[q.front()-'a']>1) q.pop();
        if(q.empty()) cout<<-1<<" ";
        else cout<<q.front()<<" ";
    }
    return 0;
}
