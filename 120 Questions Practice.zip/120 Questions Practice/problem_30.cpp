// Max Product Subarray
#include <bits/stdc++.h>
using namespace std;
int main(){int n;cin>>n; vector<long long>a(n);for(auto &x:a)cin>>x;
long long mx=a[0],mn=a[0],ans=a[0];
for(int i=1;i<n;i++){
 long long x=a[i];
 if(x<0) swap(mx,mn);
 mx=max(x,mx*x); mn=min(x,mn*x); ans=max(ans,mx);
}
cout<<ans;}