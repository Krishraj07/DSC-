// Merge Intervals
#include <bits/stdc++.h>
using namespace std;
int main(){int n;cin>>n; vector<pair<int,int>> a(n);
for(auto &p:a)cin>>p.first>>p.second; sort(a.begin(),a.end());
vector<pair<int,int>> r;
for(auto &p:a){ if(r.empty()||r.back().second<p.first) r.push_back(p);
else r.back().second=max(r.back().second,p.second);}
for(auto &p:r) cout<<p.first<<" "<<p.second<<"\n";}