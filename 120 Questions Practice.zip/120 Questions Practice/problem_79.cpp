#include <bits/stdc++.h>
using namespace std;
// Distance of nearest cell having 1 in a binary matrix (same as 76 but reading ints)
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n,m; if(!(cin>>n>>m)) return 0;
    vector<vector<int>> a(n, vector<int>(m));
    queue<pair<int,int>> q;
    vector<vector<int>> dist(n, vector<int>(m, -1));
    for(int i=0;i<n;i++) for(int j=0;j<m;j++){ cin>>a[i][j]; if(a[i][j]==1){ dist[i][j]=0; q.push({i,j}); } }
    int dx[4]={-1,1,0,0}, dy[4]={0,0,-1,1};
    while(!q.empty()){
        auto [x,y]=q.front(); q.pop();
        for(int d=0;d<4;d++){
            int nx=x+dx[d], ny=y+dy[d];
            if(nx>=0&&nx<n&&ny>=0&&ny<m && dist[nx][ny]==-1){
                dist[nx][ny]=dist[x][y]+1; q.push({nx,ny});
            }
        }
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++) cout<<dist[i][j]<<" ";
        cout<<"
";
    }
    return 0;
}
