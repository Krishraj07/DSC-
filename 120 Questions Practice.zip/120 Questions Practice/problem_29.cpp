// Factorial large
#include <bits/stdc++.h>
using namespace std;
int main(){int n;cin>>n; vector<int>res(1,1);
for(int x=2;x<=n;x++){
 int carry=0;
 for(int i=0;i<res.size();i++){
  int p=res[i]*x+carry; res[i]=p%10; carry=p/10;
 }
 while(carry){ res.push_back(carry%10); carry/=10; }
}
for(int i=res.size()-1;i>=0;i--) cout<<res[i];}