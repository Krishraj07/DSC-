// Trapping Rain Water
#include <bits/stdc++.h>
using namespace std;
int main(){int n;cin>>n; vector<int>h(n); for(int&i:h)cin>>i;
int l=0,r=n-1; long long lm=0,rm=0,ans=0;
while(l<=r){
 if(h[l]<=h[r]){
  if(h[l]>=lm) lm=h[l]; else ans+=lm-h[l];
  l++;
 } else {
  if(h[r]>=rm) rm=h[r]; else ans+=rm-h[r];
  r--;
 }
}
cout<<ans;}