// Smallest subarray > sum
#include <bits/stdc++.h>
using namespace std;int main(){int n;long long x;cin>>n>>x;vector<long long>a(n);for(auto&y:a)cin>>y;int l=0;long long sum=0;int best=1e9;for(int r=0;r<n;r++){sum+=a[r];while(sum>x){best=min(best,r-l+1);sum-=a[l++];}}cout<<(best==1e9?0:best);}