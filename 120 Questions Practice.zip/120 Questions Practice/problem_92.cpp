#include <bits/stdc++.h>
using namespace std;
// Next greater number with same digits
int main(){
    string s; if(!(cin>>s)) return 0;
    if(next_permutation(s.begin(), s.end())) cout<<s<<"\n"; else cout<<"Not Possible\n";
    return 0;
}
