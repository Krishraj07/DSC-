// Median two sorted diff size simplified merge
#include <bits/stdc++.h>
using namespace std;int main(){int n,m;cin>>n>>m;vector<long long>a(n),b(m);for(auto&x:a)cin>>x;for(auto&x:b)cin>>x;vector<long long>c;merge(a.begin(),a.end(),b.begin(),b.end(),back_inserter(c));int sz=c.size(); if(sz%2) cout<<c[sz/2]; else cout<<(c[sz/2-1]+c[sz/2])/2.0;}