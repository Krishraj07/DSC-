// Array subset check
#include <bits/stdc++.h>
using namespace std;
int main(){int n,m;cin>>n>>m; unordered_set<long long>s; long long x;
for(int i=0;i<n;i++){cin>>x; s.insert(x);}
bool ok=true;
for(int i=0;i<m;i++){cin>>x; if(!s.count(x)) ok=false;}
cout<<(ok?"Yes":"No");}