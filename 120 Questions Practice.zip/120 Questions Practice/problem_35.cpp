// Triplet sum
#include <bits/stdc++.h>
using namespace std;
int main(){int n; long long T; cin>>n>>T; vector<long long>a(n);
for(auto &x:a)cin>>x; sort(a.begin(),a.end());
for(int i=0;i<n-2;i++){
 int l=i+1,r=n-1;
 while(l<r){
  long long s=a[i]+a[l]+a[r];
  if(s==T){cout<<a[i]<<" "<<a[l]<<" "<<a[r]; return 0;}
  else if(s<T) l++;
  else r--;
 }
}
cout<<"None";}