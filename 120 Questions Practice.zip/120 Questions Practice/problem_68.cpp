#include <bits/stdc++.h>
using namespace std;
// Implement N queues in an array
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, size, q; if(!(cin>>n>>size>>q)) return 0;
    vector<int> front(n,-1), rear(n,-1), next(size);
    vector<int> arr(size);
    for(int i=0;i<size;i++) next[i]=i+1;
    next[size-1]=-1;
    int freeIdx=0;
    while(q--){
        string op; cin>>op;
        if(op=="push"){
            int si, x; cin>>si>>x;
            if(freeIdx==-1) continue;
            int idx=freeIdx; freeIdx=next[idx];
            next[idx]=-1; arr[idx]=x;
            if(front[si]==-1) front[si]=idx;
            else next[rear[si]] = idx;
            rear[si]=idx;
        } else if(op=="pop"){
            int si; cin>>si;
            if(front[si]==-1){ cout<<"Empty\n"; continue; }
            int idx=front[si]; front[si]=next[idx];
            if(front[si]==-1) rear[si]=-1;
            next[idx]=freeIdx; freeIdx=idx;
        } else if(op=="front"){
            int si; cin>>si;
            if(front[si]==-1) cout<<"Empty\n"; else cout<<arr[front[si]]<<"\n";
        }
    }
    return 0;
}
