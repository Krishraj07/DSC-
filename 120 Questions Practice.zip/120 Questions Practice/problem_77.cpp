#include <bits/stdc++.h>
using namespace std;
// Find first circular tour that visits all petrol pumps (same as gas station problem)
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n; if(!(cin>>n)) return 0;
    vector<int> petrol(n), dist(n);
    for(int i=0;i<n;i++) cin>>petrol[i];
    for(int i=0;i<n;i++) cin>>dist[i];
    int start=0; long long tank=0, total=0;
    for(int i=0;i<n;i++){
        int diff=petrol[i]-dist[i];
        tank+=diff; total+=diff;
        if(tank<0){ tank=0; start=i+1; }
    }
    if(total>=0) cout<<start<<"\n"; else cout<<-1<<"\n";
    return 0;
}
