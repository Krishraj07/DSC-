#include <bits/stdc++.h>
using namespace std;
// 119 - Making wired connections (min operations to connect all computers)
struct DSU{ int n; vector<int> p,r; DSU(int n):n(n),p(n),r(n){ iota(p.begin(),p.end(),0);} int find(int a){ return p[a]==a?a:p[a]=find(p[a]); } bool unite(int a,int b){ a=find(a); b=find(b); if(a==b) return false; if(r[a]<r[b]) swap(a,b); p[b]=a; if(r[a]==r[b]) r[a]++; return true; } };
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n,m; if(!(cin>>n>>m)) return 0;
    DSU d(n); int extra=0;
    for(int i=0;i<m;i++){ int u,v; cin>>u>>v; if(!d.unite(u,v)) extra++; }
    int comps=0; for(int i=0;i<n;i++) if(d.find(i)==i) comps++;
    int need = comps-1;
    if(extra>=need) cout<<need<<"\n"; else cout<<-1<<"\n";
    return 0;
}
