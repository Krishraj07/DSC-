#include <bits/stdc++.h>
using namespace std;
// 120 - Word Ladder (shortest transformation length)
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string beginWord, endWord; if(!(cin>>beginWord>>endWord)) return 0;
    int n; cin>>n; unordered_set<string> dict;
    for(int i=0;i<n;i++){ string w; cin>>w; dict.insert(w); }
    if(!dict.count(endWord)){ cout<<0<<"\n"; return 0; }
    queue<pair<string,int>> q; q.push({beginWord,1}); unordered_set<string> vis; vis.insert(beginWord);
    while(!q.empty()){
        auto [word,steps]=q.front(); q.pop();
        if(word==endWord){ cout<<steps<<"\n"; return 0; }
        for(int i=0;i<word.size();i++){
            string tmp=word;
            for(char c='a'; c<='z'; ++c){
                if(tmp[i]==c) continue;
                tmp[i]=c;
                if(dict.count(tmp) && !vis.count(tmp)){ vis.insert(tmp); q.push({tmp, steps+1}); }
            }
        }
    }
    cout<<0<<"\n";
    return 0;
}
