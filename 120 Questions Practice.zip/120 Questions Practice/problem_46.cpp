#include <bits/stdc++.h>
using namespace std;
int main(){int n,r;cin>>n>>r;vector<long long>a(n);for(auto&x:a)cin>>x;r%=n;
for(int i=0;i<n;i++)cout<<a[(i+r)%n]<<" ";}