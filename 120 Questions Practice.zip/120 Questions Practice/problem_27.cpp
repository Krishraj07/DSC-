// Common Elements in 3 sorted arrays
#include <bits/stdc++.h>
using namespace std;
int main(){int n1,n2,n3;cin>>n1>>n2>>n3;
vector<long long>A(n1),B(n2),C(n3);
for(auto &x:A)cin>>x; for(auto &x:B)cin>>x; for(auto &x:C)cin>>x;
int i=0,j=0,k=0; vector<long long>res;
while(i<n1&&j<n2&&k<n3){
 if(A[i]==B[j]&&B[j]==C[k]){ if(res.empty()||res.back()!=A[i]) res.push_back(A[i]);
 i++;j++;k++; }
 else{
  long long mn=min({A[i],B[j],C[k]});
  if(A[i]==mn)i++; else if(B[j]==mn)j++; else k++;
 }
}
for(auto &x:res) cout<<x<<" "; if(res.empty()) cout<<"No Common";}