#include <bits/stdc++.h>
using namespace std;
int main(){int q;cin>>q;vector<long long>st,mi;
while(q--){string c;cin>>c;if(c=="push"){long long x;cin>>x;st.push_back(x); if(mi.empty()||x<=mi.back()) mi.push_back(x);}
else if(c=="pop"){if(!st.empty()){ if(st.back()==mi.back()) mi.pop_back(); st.pop_back(); }}
else if(c=="getMin") cout<<(mi.empty()? -1:mi.back())<<"\n";}}