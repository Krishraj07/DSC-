#include <bits/stdc++.h>
using namespace std;
int main(){string s;getline(cin,s);if(s.size()==0)getline(cin,s);stack<char>st;
for(char c:s)st.push(c);while(!st.empty()){cout<<st.top();st.pop();}}