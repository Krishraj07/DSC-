#include <bits/stdc++.h>
using namespace std;
int main(){string s;cin>>s;stack<long long>st;
for(char c:s){if(isdigit(c))st.push(c-'0');
else{long long b=st.top();st.pop();long long a=st.top();st.pop();
 if(c=='+')st.push(a+b); else if(c=='-')st.push(a-b); else if(c=='*')st.push(a*b); else st.push(a/b);
}}
cout<<st.top();}