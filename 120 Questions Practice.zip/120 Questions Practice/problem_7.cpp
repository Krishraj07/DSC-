// Cyclic rotate by 1
#include <bits/stdc++.h>
using namespace std;int main(){int n;cin>>n;vector<long long>a(n);for(auto &x:a)cin>>x; if(n>0){long long last=a.back(); for(int i=n-1;i>0;i--)a[i]=a[i-1]; a[0]=last;} for(long long x:a)cout<<x<<" ";}