#include <bits/stdc++.h>
using namespace std;
int main(){int q;cin>>q;deque<long long>d;
while(q--){string c;cin>>c;if(c=="push"){long long x;cin>>x;d.push_back(x);}
else if(c=="pop"){if(!d.empty())d.pop_front();}
else if(c=="front")cout<<(d.empty()? -1:d.front())<<"\n";}}