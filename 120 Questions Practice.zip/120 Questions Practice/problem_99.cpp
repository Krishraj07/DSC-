#include <bits/stdc++.h>
using namespace std;
// Count occurrences of given string in 2D character grid (same as 96)
int main(){
    int n,m; if(!(cin>>n>>m)) return 0;
    vector<string> g(n);
    for(int i=0;i<n;i++) cin>>g[i];
    string W; cin>>W;
    int ans=0;
    function<int(int,int,int)> dfs = [&](int x,int y,int idx)->int{
        if(idx==W.size()) return 1;
        if(x<0||x>=n||y<0||y>=m||g[x][y]!=W[idx]) return 0;
        char tmp=g[x][y]; g[x][y]='#';
        int total=0;
        int dx[4]={-1,1,0,0}, dy[4]={0,0,-1,1};
        for(int d=0;d<4;d++) total+=dfs(x+dx[d], y+dy[d], idx+1);
        g[x][y]=tmp;
        return total;
    };
    for(int i=0;i<n;i++) for(int j=0;j<m;j++) ans+=dfs(i,j,0);
    cout<<ans<<"\n";
    return 0;
}
