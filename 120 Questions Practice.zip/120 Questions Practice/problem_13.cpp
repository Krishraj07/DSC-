// 3-way partition
#include <bits/stdc++.h>
using namespace std;int main(){int n;long long a1,a2;cin>>n>>a1>>a2;vector<long long>a(n);for(auto&x:a)cin>>x;int l=0,m=0,h=n-1;while(m<=h){if(a[m]<a1)swap(a[l++],a[m++]);else if(a[m]>a2)swap(a[m],a[h--]);else m++;}for(long long x:a)cout<<x<<" ";}