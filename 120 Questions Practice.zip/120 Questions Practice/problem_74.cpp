#include <bits/stdc++.h>
using namespace std;
// Gas Station - First circular tour
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n; if(!(cin>>n)) return 0;
    vector<int> gas(n), cost(n);
    for(int i=0;i<n;i++) cin>>gas[i];
    for(int i=0;i<n;i++) cin>>cost[i];
    int start=0; long long tank=0, total=0;
    for(int i=0;i<n;i++){
        int diff = gas[i]-cost[i];
        tank += diff; total += diff;
        if(tank<0){ tank=0; start=i+1; }
    }
    if(total>=0) cout<<start<<"\n"; else cout<<-1<<"\n";
    return 0;
}
