// Max/min
#include <bits/stdc++.h>
using namespace std;int main(){int n;cin>>n; long long x,mn=LLONG_MAX,mx=LLONG_MIN; while(n--){cin>>x; mn=min(mn,x); mx=max(mx,x);} cout<<mn<<" "<<mx;}