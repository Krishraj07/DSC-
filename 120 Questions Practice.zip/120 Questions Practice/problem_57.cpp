#include <bits/stdc++.h>
using namespace std;
int main(){int n;cin>>n;vector<vector<int>>M(n,vector<int>(n));
for(int i=0;i<n;i++)for(int j=0;j<n;j++)cin>>M[i][j];
int a=0,b=n-1;while(a<b){if(M[a][b])a++;else b--;}
int c=a;
for(int i=0;i<n;i++){if(i==c)continue;if(M[c][i]||!M[i][c]){cout<<-1;return 0;}}
cout<<c;}