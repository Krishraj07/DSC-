// Min jumps
#include <bits/stdc++.h>
using namespace std;int main(){int n;cin>>n;vector<int>a(n);for(int&i:a)cin>>i; if(n<=1){cout<<0;return 0;} if(a[0]==0){cout<<-1;return 0;} int maxR=a[0], step=a[0], jump=1; for(int i=1;i<n;i++){ if(i==n-1){cout<<jump;return 0;} maxR=max(maxR,i+a[i]); step--; if(step==0){ jump++; if(i>=maxR){cout<<-1;return 0;} step=maxR-i; } } cout<<-1;}