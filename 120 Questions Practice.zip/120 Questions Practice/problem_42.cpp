#include <bits/stdc++.h>
using namespace std;
struct Node{int v;Node*next;Node(int x):v(x),next(NULL){}};
int main(){int n;cin>>n;vector<Node*>a;for(int i=0;i<n;i++){int x;cin>>x;a.push_back(new Node(x));}
for(int i=0;i<n-1;i++)a[i]->next=a[i+1];int pos;cin>>pos;if(pos>=0)a.back()->next=a[pos];
Node*s=a.empty()?NULL:a[0],*f=s;while(f&&f->next){s=s->next;f=f->next->next;if(s==f){cout<<"Cycle";return 0;}}cout<<"No Cycle";}