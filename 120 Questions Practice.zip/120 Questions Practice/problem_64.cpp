#include <bits/stdc++.h>
using namespace std;
// Implement Stack using single Queue (push costly)
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int q; if(!(cin>>q)) return 0;
    queue<int> qu;
    while(q--){
        string op; cin>>op;
        if(op=="push"){
            int x; cin>>x;
            qu.push(x);
            int sz = qu.size();
            for(int i=0;i<sz-1;i++){ qu.push(qu.front()); qu.pop(); }
        } else if(op=="pop"){
            if(!qu.empty()) qu.pop();
        } else if(op=="top"){
            if(qu.empty()) cout<<"Empty\n"; else cout<<qu.front()<<"\n";
        } else if(op=="empty") cout<<(qu.empty()?"True\n":"False\n");
    }
    return 0;
}
