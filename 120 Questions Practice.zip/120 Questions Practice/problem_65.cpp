#include <bits/stdc++.h>
using namespace std;
// Implement Stack using Deque
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int q; if(!(cin>>q)) return 0;
    deque<int> dq;
    while(q--){
        string op; cin>>op;
        if(op=="push"){ int x; cin>>x; dq.push_back(x); }
        else if(op=="pop"){ if(!dq.empty()) dq.pop_back(); }
        else if(op=="top"){ if(dq.empty()) cout<<"Empty\n"; else cout<<dq.back()<<"\n"; }
        else if(op=="empty") cout<<(dq.empty()?"True\n":"False\n");
    }
    return 0;
}
