#include <bits/stdc++.h>
using namespace std;
// Count and Say
string say(const string &s){
    string out="";
    for(int i=0;i<s.size();){
        int j=i;
        while(j<s.size() && s[j]==s[i]) j++;
        out += to_string(j-i);
        out.push_back(s[i]);
        i=j;
    }
    return out;
}
int main(){
    int n; if(!(cin>>n)) return 0;
    string s="1";
    for(int i=2;i<=n;i++) s = say(s);
    cout<<s<<"\n";
    return 0;
}
