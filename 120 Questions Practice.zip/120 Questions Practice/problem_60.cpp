#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    long long K;
    cin >> n >> K;
    vector<long long> a(n);
    for (auto &x : a)
        cin >> x;
    int good = 0;
    for (long long x : a)
        if (x <= K)
            good++;
    if (good == 0)
    {
        cout << 0;
        return 0;
    }
    int bad = 0;
    for (int i = 0; i < good; i++)
        if (a[i] > K)
            bad++;
    int ans = bad;
    for (int i = 0, j = good; j < n; i++, j++)
    {
        if (a[i] > K)
            bad--;
        if (a[j] > K)
            bad++;
        ans = min(ans, bad);
    }
    cout << ans;
}