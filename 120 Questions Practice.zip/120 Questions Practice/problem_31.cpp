// Longest consecutive sequence
#include <bits/stdc++.h>
using namespace std;
int main(){int n;cin>>n; unordered_set<long long>s; long long x;
for(int i=0;i<n;i++){cin>>x; s.insert(x);}
int best=0;
for(long long v:s){
 if(!s.count(v-1)){
  int len=1; long long t=v+1;
  while(s.count(t)){len++;t++;}
  best=max(best,len);
 }
}
cout<<best;}