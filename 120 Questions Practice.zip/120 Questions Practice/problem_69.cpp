#include <bits/stdc++.h>
using namespace std;
// Circular Queue implementation
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int size,q; if(!(cin>>size>>q)) return 0;
    vector<int> arr(size);
    int front=-1, rear=-1;
    while(q--){
        string op; cin>>op;
        if(op=="push"){
            int x; cin>>x;
            if((rear+1)%size==front) continue; // full
            if(front==-1){ front=rear=0; arr[rear]=x; }
            else { rear=(rear+1)%size; arr[rear]=x; }
        } else if(op=="pop"){
            if(front==-1) continue;
            if(front==rear) front=rear=-1;
            else front=(front+1)%size;
        } else if(op=="front"){
            if(front==-1) cout<<"Empty\n"; else cout<<arr[front]<<"\n";
        }
    }
    return 0;
}
