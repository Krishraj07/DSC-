#include <bits/stdc++.h>
using namespace std;
// Longest Palindromic Substring (expand center)
int main(){
    string s; if(!(cin>>s)) return 0;
    int n=s.size(), start=0, best=1;
    auto expand=[&](int l,int r){
        while(l>=0 && r<n && s[l]==s[r]){ l--; r++; }
        return r-l-1;
    };
    for(int i=0;i<n;i++){
        int l1=expand(i,i);
        int l2=expand(i,i+1);
        int len=max(l1,l2);
        if(len>best){ best=len; start = i - (len-1)/2; }
    }
    cout<<s.substr(start,best)<<"\n";
    return 0;
}
