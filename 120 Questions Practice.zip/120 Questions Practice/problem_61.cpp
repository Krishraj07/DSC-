#include <bits/stdc++.h>
using namespace std;
// Largest Rectangular Area in Histogram
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    if (!(cin >> n))
        return 0;
    vector<long long> h(n);
    for (int i = 0; i < n; i++)
        cin >> h[i];
    stack<int> st;
    long long maxA = 0;
    int i = 0;
    while (i < n)
    {
        if (st.empty() || h[st.top()] <= h[i])
            st.push(i++);
        else
        {
            int tp = st.top();
            st.pop();
            long long width = st.empty() ? i : i - st.top() - 1;
            maxA = max(maxA, h[tp] * width);
        }
    }
    while (!st.empty())
    {
        int tp = st.top();
        st.pop();
        long long width = st.empty() ? i : i - st.top() - 1;
        maxA = max(maxA, h[tp] * width);
    }
    cout << maxA << "";
    return 0;
}
