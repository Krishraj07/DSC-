// Min operations make array palindromic merge
#include <bits/stdc++.h>
using namespace std;int main(){int n;cin>>n;vector<long long>a(n);for(auto&x:a)cin>>x;int i=0,j=n-1,ops=0;while(i<j){if(a[i]==a[j]){i++;j--;}else if(a[i]<a[j]){a[i+1]+=a[i];i++;ops++;}else{a[j-1]+=a[j];j--;ops++;}}cout<<ops;}