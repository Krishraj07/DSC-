#include <bits/stdc++.h>
using namespace std;
// (Reserve) Placeholder
int main(){ string s; if(!(cin>>s)) return 0; cout<<s<<"\n"; return 0; }
