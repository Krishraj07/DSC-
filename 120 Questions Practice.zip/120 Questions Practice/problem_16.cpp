// Median two sorted equal size
#include <bits/stdc++.h>
using namespace std;int main(){int n;cin>>n;vector<long long>a(n),b(n);for(auto&x:a)cin>>x;for(auto&x:b)cin>>x;int i=0,j=0,c1=-1,c2=-1;for(int k=0;k<=n;k++){long long val; if(i<n && (j>=n||a[i]<=b[j])) val=a[i++]; else val=b[j++]; if(k==n-1) c1=val; if(k==n) c2=val;} cout<<(c1+c2)/2.0;} 