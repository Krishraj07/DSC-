#include <bits/stdc++.h>
using namespace std;
// Print all subsequences
void solve(const string &s,int i,string cur){
    if(i==s.size()){ cout<<cur<<"\n"; return; }
    solve(s,i+1,cur);
    solve(s,i+1,cur + s[i]);
}
int main(){ string s; if(!(cin>>s)) return 0; solve(s,0,""); return 0; }
