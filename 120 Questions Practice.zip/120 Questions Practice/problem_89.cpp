#include <bits/stdc++.h>
using namespace std;
// Split binary string into substrings with equal 0s and 1s
int main(){
    string s; if(!(cin>>s)) return 0;
    int zeros=0, ones=0, cnt=0;
    for(char c: s){
        if(c=='0') zeros++; else ones++;
        if(zeros==ones) cnt++;
    }
    cout<<(cnt==0? -1 : cnt) <<"\n";
    return 0;
}
