#include <bits/stdc++.h>
using namespace std;
// 107 - Minimum swaps for bracket balancing (only [])
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string s; if(!(cin>>s)) return 0;
    int imbalance=0, open=0;
    for(char c: s){
        if(c=='[') open++;
        else{
            if(open>0) open--;
            else imbalance++;
        }
    }
    cout<< (imbalance+1)/2 <<"\n";
    return 0;
}
