#include <bits/stdc++.h>
using namespace std;
// 109 - Generate all valid IP addresses from string
bool valid(const string &s){
    if(s.empty() || s.size()>3) return false;
    if(s.size()>1 && s[0]=='0') return false;
    int v=stoi(s); return v>=0 && v<=255;
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string s; if(!(cin>>s)) return 0;
    int n=s.size();
    for(int i=1;i<=3;i++) for(int j=1;j<=3;j++) for(int k=1;k<=3;k++){
        int l = n - (i+j+k);
        if(l>=1 && l<=3){
            string a=s.substr(0,i), b=s.substr(i,j), c=s.substr(i+j,k), d=s.substr(i+j+k,l);
            if(valid(a)&&valid(b)&&valid(c)&&valid(d)){
                cout<<a<<"."<<b<<"."<<c<<"."<<d<<"\n";
            }
        }
    }
    return 0;
}
