#include <bits/stdc++.h>
using namespace std;
// Count occurrences of word in 2D grid (DFS)
int n,m;
vector<string> g;
string W;
int dx[4]={-1,1,0,0}, dy[4]={0,0,-1,1};
int dfs(int x,int y,int idx){
    if(idx==W.size()) return 1;
    if(x<0||x>=n||y<0||y>=m||g[x][y]!=W[idx]) return 0;
    char tmp=g[x][y]; g[x][y]='#';
    int total=0;
    for(int d=0;d<4;d++) total += dfs(x+dx[d], y+dy[d], idx+1);
    g[x][y]=tmp;
    return total;
}
int main(){
    if(!(cin>>n>>m)) return 0;
    g.resize(n);
    for(int i=0;i<n;i++) cin>>g[i];
    cin>>W;
    int ans=0;
    for(int i=0;i<n;i++) for(int j=0;j<m;j++) ans += dfs(i,j,0);
    cout<<ans<<"\n";
    return 0;
}
