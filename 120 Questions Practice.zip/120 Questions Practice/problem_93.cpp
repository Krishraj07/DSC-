#include <bits/stdc++.h>
using namespace std;
// Balanced Parenthesis
bool match(char a,char b){ return (a=='('&&b==')')||(a=='['&&b==']')||(a=='{'&&b=='}'); }
int main(){
    string s; if(!(cin>>s)) return 0;
    stack<char> st;
    for(char c: s){
        if(c=='('||c=='['||c=='{') st.push(c);
        else{
            if(st.empty() || !match(st.top(), c)){ cout<<"No\n"; return 0; }
            st.pop();
        }
    }
    cout<<(st.empty()?"Yes\n":"No\n");
    return 0;
}
