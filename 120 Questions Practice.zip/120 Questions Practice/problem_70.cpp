#include <bits/stdc++.h>
using namespace std;
// LRU Cache
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int cap,q; if(!(cin>>cap>>q)) return 0;
    list<pair<int,int>> lru;
    unordered_map<int, list<pair<int,int>>::iterator> mp;
    while(q--){
        string op; cin>>op;
        if(op=="get"){
            int key; cin>>key;
            if(!mp.count(key)) cout<<-1<<"\n";
            else{
                auto it=mp[key];
                int val=it->second;
                lru.erase(it);
                lru.push_front({key,val});
                mp[key]=lru.begin();
                cout<<val<<"\n";
            }
        } else if(op=="put"){
            int key,val; cin>>key>>val;
            if(mp.count(key)) { lru.erase(mp[key]); mp.erase(key); }
            if((int)lru.size()==cap){ auto last=lru.back(); mp.erase(last.first); lru.pop_back(); }
            lru.push_front({key,val}); mp[key]=lru.begin();
        }
    }
    return 0;
}
