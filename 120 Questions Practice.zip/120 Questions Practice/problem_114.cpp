#include <bits/stdc++.h>
using namespace std;
// 114 - Detect cycle in undirected graph using DFS + parent
bool dfs(int u,int p, vector<int>& vis, vector<vector<int>>& g){
    vis[u]=1;
    for(int v: g[u]){
        if(!vis[v]){ if(dfs(v,u,vis,g)) return true; }
        else if(v!=p) return true;
    }
    return false;
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n,m; if(!(cin>>n>>m)) return 0;
    vector<vector<int>> g(n);
    for(int i=0;i<m;i++){ int u,v; cin>>u>>v; g[u].push_back(v); g[v].push_back(u); }
    vector<int> vis(n,0);
    for(int i=0;i<n;i++) if(!vis[i]) if(dfs(i,-1,vis,g)){ cout<<"Cycle\n"; return 0; }
    cout<<"No Cycle\n";
    return 0;
}
