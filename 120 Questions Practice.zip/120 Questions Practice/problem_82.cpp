#include <bits/stdc++.h>
using namespace std;
// Next Smaller Element
int main(){
    int n; if(!(cin>>n)) return 0;
    vector<long long> a(n), ans(n, -1);
    for(int i=0;i<n;i++) cin>>a[i];
    stack<int> st;
    for(int i=0;i<n;i++){
        while(!st.empty() && a[st.top()]>a[i]){
            ans[st.top()]=a[i]; st.pop();
        }
        st.push(i);
    }
    for(int i=0;i<n;i++) cout<<ans[i]<<" ";
    return 0;
}
