#include <bits/stdc++.h>
using namespace std;
int p(char c){if(c=='+'||c=='-')return 1;if(c=='*'||c=='/')return 2;return 0;}
long long op(long long a,long long b,char c){if(c=='+')return a+b;if(c=='-')return a-b;if(c=='*')return a*b;return a/b;}
int main(){string s;cin>>s;stack<long long>v;stack<char>o;
for(int i=0;i<s.size();){
 if(isdigit(s[i])){long long x=0;while(i<s.size()&&isdigit(s[i]))x=x*10+s[i++]-'0';v.push(x);}
 else if(s[i]=='(')o.push(s[i++]);
 else if(s[i]==')'){while(!o.empty()&&o.top()!='('){long long b=v.top();v.pop();long long a=v.top();v.pop();char c=o.top();o.pop();v.push(op(a,b,c));}o.pop();i++;}
 else{ while(!o.empty()&&p(o.top())>=p(s[i])){long long b=v.top();v.pop();long long a=v.top();v.pop();char c=o.top();o.pop();v.push(op(a,b,c));}o.push(s[i++]); }
}
while(!o.empty()){long long b=v.top();v.pop();long long a=v.top();v.pop();char c=o.top();o.pop();v.push(op(a,b,c));}
cout<<v.top();}