#include <bits/stdc++.h>
using namespace std;
// Expression contains redundant brackets
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string s; if(!(cin>>s)) return 0;
    stack<char> st;
    for(char c: s){
        if(c==')'){
            bool opFound=false;
            while(!st.empty() && st.top()!='('){
                char t=st.top(); st.pop();
                if(t=='+'||t=='-'||t=='*'||t=='/') opFound=true;
            }
            if(st.empty()){ cout<<"No\n"; return 0; }
            st.pop(); // pop '('
            if(!opFound){ cout<<"Yes\n"; return 0; }
        } else st.push(c);
    }
    cout<<"No\n";
    return 0;
}
