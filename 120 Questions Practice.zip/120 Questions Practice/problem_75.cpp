#include <bits/stdc++.h>
using namespace std;
// Rotten Oranges - min time to rot all
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n,m; if(!(cin>>n>>m)) return 0;
    vector<vector<int>> g(n, vector<int>(m));
    queue<pair<int,int>> q;
    int fresh=0;
    for(int i=0;i<n;i++) for(int j=0;j<m;j++){ cin>>g[i][j]; if(g[i][j]==2) q.push({i,j}); else if(g[i][j]==1) fresh++; }
    int t=0;
    int dx[4]={-1,1,0,0}, dy[4]={0,0,-1,1};
    while(!q.empty() && fresh>0){
        int sz=q.size();
        while(sz--){
            auto [x,y]=q.front(); q.pop();
            for(int d=0;d<4;d++){
                int nx=x+dx[d], ny=y+dy[d];
                if(nx>=0 && nx<n && ny>=0 && ny<m && g[nx][ny]==1){
                    g[nx][ny]=2; fresh--; q.push({nx,ny});
                }
            }
        }
        t++;
    }
    cout<<(fresh==0? t : -1) <<"\n";
    return 0;
}
