// Rearrange alternatively pos/neg
#include <bits/stdc++.h>
using namespace std;
int main(){int n;cin>>n; vector<long long>a(n),pos,neg;
for(auto &x:a){cin>>x; (x>=0?pos:neg).push_back(x);}
vector<long long>res; int i=0,j=0;
while(i<pos.size()&&j<neg.size()){ res.push_back(pos[i++]); res.push_back(neg[j++]); }
while(i<pos.size()) res.push_back(pos[i++]);
while(j<neg.size()) res.push_back(neg[j++]);
for(auto &x:res) cout<<x<<" ";}