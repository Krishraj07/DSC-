#include <bits/stdc++.h>
using namespace std;
// 106 - First repeated word (case-insensitive)
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string line;
    getline(cin, line);
    if(line.size()==0) getline(cin,line);
    transform(line.begin(), line.end(), line.begin(), ::tolower);
    stringstream ss(line);
    unordered_set<string> seen;
    string w;
    while(ss>>w){
        if(seen.count(w)){ cout<<w<<"\n"; return 0; }
        seen.insert(w);
    }
    cout<<"None\n";
    return 0;
}
