#include <bits/stdc++.h>
using namespace std;
int main(){int q;cin>>q;vector<long long>s;
while(q--){string c;cin>>c;if(c=="push"){long long x;cin>>x;s.push_back(x);}
else if(c=="pop"){if(!s.empty())s.pop_back();}
else if(c=="middle"){if(s.empty())cout<<"Empty\n";else cout<<s[(s.size()-1)/2]<<"\n";}}}