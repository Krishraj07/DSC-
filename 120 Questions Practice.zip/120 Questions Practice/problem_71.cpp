#include <bits/stdc++.h>
using namespace std;
// Reverse queue using recursion
void rev(queue<int>&q){
    if(q.empty()) return;
    int x=q.front(); q.pop();
    rev(q);
    q.push(x);
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n; if(!(cin>>n)) return 0;
    queue<int> q;
    for(int i=0;i<n;i++){ int x; cin>>x; q.push(x); }
    rev(q);
    while(!q.empty()){ cout<<q.front()<<" "; q.pop(); }
    return 0;
}
