#include <bits/stdc++.h>
using namespace std;
// 105 - Min flips to make binary string alternate
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string s; if(!(cin>>s)) return 0;
    int n=s.size();
    int flips0=0, flips1=0;
    for(int i=0;i<n;i++){
        char want0 = (i%2==0)?'0':'1';
        char want1 = (i%2==0)?'1':'0';
        if(s[i]!=want0) flips0++;
        if(s[i]!=want1) flips1++;
    }
    cout<<min(flips0, flips1)<<"\n";
    return 0;
}
