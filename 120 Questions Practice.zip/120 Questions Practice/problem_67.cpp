#include <bits/stdc++.h>
using namespace std;
// Implement Queue using two Stacks
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int q; if(!(cin>>q)) return 0;
    stack<int> s1,s2;
    while(q--){
        string op; cin>>op;
        if(op=="push"){ int x; cin>>x; s1.push(x); }
        else if(op=="pop"){
            if(s2.empty()){ while(!s1.empty()){ s2.push(s1.top()); s1.pop(); } }
            if(!s2.empty()) s2.pop();
        } else if(op=="front"){
            if(s2.empty()){ while(!s1.empty()){ s2.push(s1.top()); s1.pop(); } }
            if(s2.empty()) cout<<"Empty\n"; else cout<<s2.top()<<"\n";
        }
    }
    return 0;
}
