// Union & intersection
#include <bits/stdc++.h>
using namespace std;int main(){int n,m;cin>>n>>m;vector<long long>a(n),b(m);for(auto &x:a)cin>>x;for(auto &x:b)cin>>x;set<long long>u(a.begin(),a.end());u.insert(b.begin(),b.end());for(auto x:u)cout<<x<<" ";cout<<"\n";set<long long>i; for(long long x:a) if(binary_search(b.begin(),b.end(),x)) i.insert(x); for(auto x:i)cout<<x<<" ";}