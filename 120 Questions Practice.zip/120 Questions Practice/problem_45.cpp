#include <bits/stdc++.h>
using namespace std;
int main(){int n,k;cin>>n>>k;vector<long long>a(n);for(auto&x:a)cin>>x;
priority_queue<long long,vector<long long>,greater<long long>>pq;
int idx=0;for(int i=0;i<min(n,k+1);i++)pq.push(a[i]);vector<long long>out;
for(int i=k+1;i<n;i++){out.push_back(pq.top());pq.pop();pq.push(a[i]);}
while(!pq.empty()){out.push_back(pq.top());pq.pop();}
for(auto &x:out)cout<<x<<" ";}