#include <bits/stdc++.h>
using namespace std;
// 101 - Search a word in 2D grid (8 directions)
int n,m;
vector<string> g;
string W;
int dx[8]={-1,-1,-1,0,0,1,1,1}, dy[8]={-1,0,1,-1,1,-1,0,1};
bool dfs(int x,int y,int idx){
    if(idx==W.size()) return true;
    if(x<0||x>=n||y<0||y>=m||g[x][y]!=W[idx]) return false;
    char tmp=g[x][y]; g[x][y]='#';
    for(int d=0;d<8;d++) if(dfs(x+dx[d], y+dy[d], idx+1)){ g[x][y]=tmp; return true; }
    g[x][y]=tmp;
    return false;
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    if(!(cin>>n>>m)) return 0;
    g.assign(n,""); for(int i=0;i<n;i++) cin>>g[i];
    cin>>W;
    for(int i=0;i<n;i++) for(int j=0;j<m;j++){
        if(g[i][j]==W[0] && dfs(i,j,0)){ cout<<"Yes\n"; return 0; }
    }
    cout<<"No\n";
    return 0;
}
