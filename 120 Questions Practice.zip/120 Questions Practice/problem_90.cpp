#include <bits/stdc++.h>
using namespace std;
// Word Wrap (minimum badness)
int main(){
    int n; if(!(cin>>n)) return 0;
    int k; cin>>k;
    vector<int> a(n);
    for(int i=0;i<n;i++) cin>>a[i];
    const int INF = 1e9;
    vector<int> dp(n+1, INF);
    dp[n]=0;
    for(int i=n-1;i>=0;i--){
        int len=0;
        for(int j=i;j<n;j++){
            len += a[j];
            if(len > k) break;
            int extra = k - len;
            int cost = (j==n-1)? 0 : extra*extra;
            dp[i] = min(dp[i], cost + dp[j+1]);
            len++; // space
        }
    }
    cout<<dp[0]<<"\n";
    return 0;
}
