#include <bits/stdc++.h>
using namespace std;
// (Start of next module) simple placeholder: print OK
int main(){ cout<<"OK"<<"\n"; return 0; }
