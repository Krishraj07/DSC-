#include <bits/stdc++.h>
using namespace std;
// 112 - DFS traversal (recursive)
void dfs(int u, vector<int>& vis, vector<vector<int>>& g){
    vis[u]=1; cout<<u<<" ";
    for(int v: g[u]) if(!vis[v]) dfs(v, vis, g);
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n,m; if(!(cin>>n>>m)) return 0;
    vector<vector<int>> g(n);
    for(int i=0;i<m;i++){ int u,v; cin>>u>>v; g[u].push_back(v); g[v].push_back(u); }
    int s; cin>>s;
    vector<int> vis(n,0);
    dfs(s,vis,g);
    cout<<"\n";
    return 0;
}
