#include <bits/stdc++.h>
using namespace std;
// 102 - Boyer-Moore (bad character heuristic)
int bm_search(const string &txt, const string &pat){
    int n=txt.size(), m=pat.size();
    if(m==0) return 0;
    vector<int> bad(256, -1);
    for(int i=0;i<m;i++) bad[(unsigned char)pat[i]] = i;
    int s=0;
    while(s <= n-m){
        int j=m-1;
        while(j>=0 && pat[j]==txt[s+j]) j--;
        if(j<0) return s;
        int bc = bad[(unsigned char)txt[s+j]];
        s += max(1, j - bc);
    }
    return -1;
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string t,p; if(!(cin>>t>>p)) return 0;
    cout<<bm_search(t,p)<<"\n";
    return 0;
}
