#include <bits/stdc++.h>
using namespace std;
// Word Break (dictionary given)
int main(){
    string s; if(!(cin>>s)) return 0;
    int n; cin>>n;
    unordered_set<string> dict;
    for(int i=0;i<n;i++){ string w; cin>>w; dict.insert(w); }
    int L=s.size();
    vector<int> dp(L+1,0); dp[0]=1;
    for(int i=1;i<=L;i++){
        for(int j=0;j<i;j++){
            if(dp[j] && dict.count(s.substr(j,i-j))){ dp[i]=1; break; }
        }
    }
    cout<<(dp[L]?"Yes":"No")<<"\n";
    return 0;
}
