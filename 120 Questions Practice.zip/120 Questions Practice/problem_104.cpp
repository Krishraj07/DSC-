#include <bits/stdc++.h>
using namespace std;
// 104 - Longest Common Prefix
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n; if(!(cin>>n)) return 0;
    vector<string> a(n);
    for(int i=0;i<n;i++) cin>>a[i];
    if(n==0){ cout<<"\n"; return 0; }
    string pref=a[0];
    for(int i=1;i<n;i++){
        int j=0;
        while(j<pref.size() && j<a[i].size() && pref[j]==a[i][j]) j++;
        pref = pref.substr(0,j);
    }
    cout<<pref<<"\n";
    return 0;
}
