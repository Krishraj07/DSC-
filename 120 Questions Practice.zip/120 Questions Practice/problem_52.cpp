#include <bits/stdc++.h>
using namespace std;
int main(){int n,size,q;cin>>n>>size>>q;
vector<int>front(n,-1),rear(n,-1),nxt(size);for(int i=0;i<size;i++)nxt[i]=i+1; nxt[size-1]=-1;
vector<long long>a(size); int freeIdx=0;
while(q--){string c;cin>>c;if(c=="push"){int si; long long x;cin>>si>>x;
 if(freeIdx==-1)continue; int idx=freeIdx; freeIdx=nxt[idx]; nxt[idx]=-1;
 if(front[si]==-1)front[si]=idx; else nxt[rear[si]]=idx; rear[si]=idx; a[idx]=x; }
 else if(c=="pop"){int si;cin>>si; if(front[si]==-1){cout<<"Empty\n";continue;}
 int idx=front[si]; front[si]=nxt[idx]; if(front[si]==-1)rear[si]=-1; nxt[idx]=freeIdx; freeIdx=idx;}
 else if(c=="front"){int si;cin>>si; if(front[si]==-1)cout<<"Empty\n"; else cout<<a[front[si]]<<"\n";}}
}