// Chocolate distribution
#include <bits/stdc++.h>
using namespace std;
int main(){int n,m;cin>>n; vector<long long>a(n);for(auto&x:a)cin>>x;cin>>m;
sort(a.begin(),a.end()); long long ans=LLONG_MAX;
for(int i=0;i+m<=n;i++) ans=min(ans,a[i+m-1]-a[i]);
cout<<ans;}