#include <bits/stdc++.h>
using namespace std;
int main(){int n,q;cin>>n>>q;vector<long long>a(n);int t1=-1,t2=n;
while(q--){string c;cin>>c;if(c=="push1"){long long x;cin>>x;if(t1+1<t2)a[++t1]=x;}
else if(c=="push2"){long long x;cin>>x;if(t1+1<t2)a[--t2]=x;}
else if(c=="pop1"){if(t1>=0)t1--;}
else if(c=="pop2"){if(t2<n)t2++;}}
}